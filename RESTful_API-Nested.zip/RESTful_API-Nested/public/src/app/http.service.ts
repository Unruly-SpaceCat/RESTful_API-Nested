import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) {
    //this.getTasks();
    //this.getOneTask();
   }
   getTasks(){
     return this._http.get('/tasks');
     //tempObservable.subscribe(data => console.log("Got our tasks!", data));
   }
   createnew(newtask) {
     return this._http.post('/tasks', newtask)
   }

   deleteTask(id){
     return this._http.delete('/tasks/' + id)
   }

   updateTask(tasktoedit){
     return this._http.put('/tasks/' + tasktoedit._id, tasktoedit)
   }
   //getOneTask(){
   // let tempObservable = this._http.get('/tasks/:id');
   // tempObservable.subscribe(data => console.log("Got the task!", data));
   //}
}
