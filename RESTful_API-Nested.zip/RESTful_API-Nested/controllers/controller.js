var Task = require('../models/task');

// Export functions for our routes.js file to use. This is where the logic of
// your server will go.
module.exports = {

    home_function: function(req, res){
        console.log("get all")
        tasks = Task.find().sort({createdAt: -1})
        .then(tasks=>  {
            var response = {}
            response['message'] = "Success"
            response['tasks'] = tasks
            res.json(response)
        })
        .catch(err => res.json(err))
    },
    get_one: function(req, res){
        const { id } = req.params
        Task.findOne({_id: id })
        .then(task => res.json(task))
        .catch(err => res.json(err))
    },
    create_one: function(req, res){
        console.log(req.body)
        const newtask = new Task()
        newtask.title = req.body.title
        newtask.description = req.body.description
        newtask.completed = req.body.completed
        newtask.save()
        .then(newTask => {
            console.log("new tasked saved", newTask)
            res.redirect('/tasks')
        })
        .catch(err => {
            console.log(err)
            res.json(err)
        })
    },
    update_one: function(req, res){
        const { id } = req.params
        console.log(id)
        console.log(req.body)
        Task.findOne({_id: id })
        .then(task => {
            console.log(task)
            task.title = req.body.title
            task.description = req.body.description
            if(req.body.completed !== task.completed){
                task.completed = req.body.completed
            }
            task.save() 
            console.log(task)
            res.end()         
        })
        .catch(err => res.json(err))
        .then(updatedtask => {
            console.log("updated task", updatedtask)
            var response = {}
            response['message'] = "Success"
            res.json(response)
        })
    },
    delete_one: function(req, res){
        const { id } = req.params       
        Task.deleteOne({_id: id })
        .then(deletedtask => {
            console.log(deletedtask)
            var response = {}
            response['message'] = "Success"
            res.json(response)
        })
         .catch(err => {
             console.log(err)
             res.redirect('/tasks')
        })
    }
}